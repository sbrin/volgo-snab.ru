<?php return array (
  'f3584c3e9f4f4b3fabfd13c6e20e2f5c' => 
  array (
    'files' => 
    array (
      0 => '/home/u177883/stroikomplekt34.ru/www/core/components',
    ),
  ),
);