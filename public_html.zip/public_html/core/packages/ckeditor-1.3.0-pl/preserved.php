<?php return array (
  'a249b42cbcb2baff68949cecc05996b4' => 
  array (
    'criteria' => 
    array (
      'name' => 'ckeditor',
    ),
    'object' => 
    array (
      'name' => 'ckeditor',
      'path' => '{core_path}components/ckeditor/',
      'assets_path' => '',
    ),
  ),
  'c76eeaa05cf184efcf771305bc5470d8' => 
  array (
    'criteria' => 
    array (
      'name' => 'CKEditor',
    ),
    'object' => 
    array (
      'id' => 3,
      'source' => 0,
      'property_preprocess' => 0,
      'name' => 'CKEditor',
      'description' => 'CKEditor WYSIWYG editor plugin for MODx Revolution',
      'editor_type' => 0,
      'category' => 0,
      'cache_type' => 0,
      'plugincode' => '/**
 * CKEditor WYSIWYG Editor Plugin
 *
 * Events: OnManagerPageBeforeRender, OnRichTextEditorRegister, OnRichTextBrowserInit, OnDocFormPrerender
 *
 * @author Danil Kostin <danya.postfactum(at)gmail.com>
 *
 * @package ckeditor
 */

if ($modx->event->name == \'OnRichTextEditorRegister\') {
    $modx->event->output(\'CKEditor\');
    return;
}

if ($modx->getOption(\'which_editor\',null,\'CKEditor\') !== \'CKEditor\' || !$modx->getOption(\'use_editor\',null,true)) {
    return;
}

if ($modx->event->name == \'OnRichTextBrowserInit\') {
    $funcNum = $_REQUEST[\'CKEditorFuncNum\'];
    $modx->event->output("function(data){
        window.parent.opener.CKEDITOR.tools.callFunction({$funcNum}, data.fullRelativeUrl);
    }");
    return;
}

$ckeditor = $modx->getService(\'ckeditor\',\'CKEditor\',$modx->getOption(\'ckeditor.core_path\',null,$modx->getOption(\'core_path\').\'components/ckeditor/\').\'model/ckeditor/\');

$ckeditor->initialize();

if ($modx->event->name == \'OnDocFormPrerender\') {
    $richText = $modx->controller->resourceArray[\'richtext\'];
    $classKey = $modx->controller->resourceArray[\'class_key\'];

    if ($richText && !in_array($classKey, array(\'modStaticResource\',\'modSymLink\',\'modWebLink\',\'modXMLRPCResource\'))) {
        $selector = \'#ta, .modx-richtext\';
    } else {
        $selector = \'.modx-richtext\';
    }

    $modx->controller->addHtml(\'<script>\'."
        Ext.onReady(function() {
            var textAreas = Ext.query(\'$selector\');
            textAreas.forEach(function(textArea){
                var htmlEditor = MODx.load({
                    xtype: \'modx-htmleditor\',
                    width: \'auto\',
                    height: parseInt(textArea.style.height) || 200,
                    name: textArea.name,
                    value: textArea.value || \'<p></p>\'
                });

                textArea.name = \'\';
                textArea.style.display = \'none\';

                htmlEditor.render(textArea.parentNode);
                htmlEditor.editor.on(\'key\', function(e){ MODx.fireResourceFormChange() });
            });
        });
    ".\'</script>\');
}

return;',
      'locked' => 0,
      'properties' => NULL,
      'disabled' => 0,
      'moduleguid' => '',
      'static' => 1,
      'static_file' => 'ckeditor/elements/plugins/ckeditor.plugin.php',
      'content' => '/**
 * CKEditor WYSIWYG Editor Plugin
 *
 * Events: OnManagerPageBeforeRender, OnRichTextEditorRegister, OnRichTextBrowserInit, OnDocFormPrerender
 *
 * @author Danil Kostin <danya.postfactum(at)gmail.com>
 *
 * @package ckeditor
 */

if ($modx->event->name == \'OnRichTextEditorRegister\') {
    $modx->event->output(\'CKEditor\');
    return;
}

if ($modx->getOption(\'which_editor\',null,\'CKEditor\') !== \'CKEditor\' || !$modx->getOption(\'use_editor\',null,true)) {
    return;
}

if ($modx->event->name == \'OnRichTextBrowserInit\') {
    $funcNum = $_REQUEST[\'CKEditorFuncNum\'];
    $modx->event->output("function(data){
        window.parent.opener.CKEDITOR.tools.callFunction({$funcNum}, data.fullRelativeUrl);
    }");
    return;
}

$ckeditor = $modx->getService(\'ckeditor\',\'CKEditor\',$modx->getOption(\'ckeditor.core_path\',null,$modx->getOption(\'core_path\').\'components/ckeditor/\').\'model/ckeditor/\');

$ckeditor->initialize();

if ($modx->event->name == \'OnDocFormPrerender\') {
    $richText = $modx->controller->resourceArray[\'richtext\'];
    $classKey = $modx->controller->resourceArray[\'class_key\'];

    if ($richText && !in_array($classKey, array(\'modStaticResource\',\'modSymLink\',\'modWebLink\',\'modXMLRPCResource\'))) {
        $selector = \'#ta, .modx-richtext\';
    } else {
        $selector = \'.modx-richtext\';
    }

    $modx->controller->addHtml(\'<script>\'."
        Ext.onReady(function() {
            var textAreas = Ext.query(\'$selector\');
            textAreas.forEach(function(textArea){
                var htmlEditor = MODx.load({
                    xtype: \'modx-htmleditor\',
                    width: \'auto\',
                    height: parseInt(textArea.style.height) || 200,
                    name: textArea.name,
                    value: textArea.value || \'<p></p>\'
                });

                textArea.name = \'\';
                textArea.style.display = \'none\';

                htmlEditor.render(textArea.parentNode);
                htmlEditor.editor.on(\'key\', function(e){ MODx.fireResourceFormChange() });
            });
        });
    ".\'</script>\');
}

return;',
    ),
    'files' => 
    array (
      0 => '/home/u177883/stroikomplekt34.ru/www/core/components',
    ),
  ),
  'fefe49ed261a62ab6ab5087139cc5210' => 
  array (
    'criteria' => 
    array (
      'pluginid' => 3,
      'event' => 'OnManagerPageBeforeRender',
    ),
    'object' => 
    array (
      'pluginid' => 3,
      'event' => 'OnManagerPageBeforeRender',
      'priority' => 0,
      'propertyset' => 0,
    ),
  ),
  'd3624c6ed3d78cefae41d6b0d844685e' => 
  array (
    'criteria' => 
    array (
      'pluginid' => 3,
      'event' => 'OnRichTextEditorRegister',
    ),
    'object' => 
    array (
      'pluginid' => 3,
      'event' => 'OnRichTextEditorRegister',
      'priority' => 0,
      'propertyset' => 0,
    ),
  ),
  '02728fff0941d6273fd0f68dceabfed5' => 
  array (
    'criteria' => 
    array (
      'pluginid' => 3,
      'event' => 'OnRichTextBrowserInit',
    ),
    'object' => 
    array (
      'pluginid' => 3,
      'event' => 'OnRichTextBrowserInit',
      'priority' => 0,
      'propertyset' => 0,
    ),
  ),
  '4c6a7c2ad7d9ef1827c1ccaf6927fc3c' => 
  array (
    'criteria' => 
    array (
      'key' => 'ckeditor.ui_color',
    ),
    'object' => 
    array (
      'key' => 'ckeditor.ui_color',
      'value' => '#DDDDDD',
      'xtype' => 'textfield',
      'namespace' => 'ckeditor',
      'area' => 'general',
      'editedon' => '0000-00-00 00:00:00',
    ),
  ),
  '3fca41d828397d290922dd1281e96405' => 
  array (
    'criteria' => 
    array (
      'key' => 'ckeditor.toolbar',
    ),
    'object' => 
    array (
      'key' => 'ckeditor.toolbar',
      'value' => '[
    { "name": "clipboard", "groups": [ "clipboard", "undo" ], "items": [ "Cut", "Copy", "Paste", "PasteText", "PasteFromWord", "-", "Undo", "Redo" ] },
    { "name": "links", "items": [ "Link", "Unlink"] },
    { "name": "insert", "items": [ "Image", "Flash", "Table", "HorizontalRule", "SpecialChar", "Iframe" ] },
    { "name": "editing", "items": [ "Find", "Replace" ] },
    { "name": "tools", "items": [ "Maximize", "ShowBlocks" ] },
    { "name": "document", "groups": [ "mode" ], "items": [ "Source"] },
    "/",
    { "name": "basicstyles", "groups": [ "basicstyles", "cleanup" ], "items": [ "Bold", "Italic", "Subscript", "Superscript", "-", "RemoveFormat" ] },
    { "name": "paragraph", "groups": [ "list", "indent", "blocks", "align" ], "items": [ "NumberedList", "BulletedList", "-", "Outdent", "Indent", "-", "Blockquote", "CreateDiv", "-", "JustifyLeft", "JustifyCenter", "JustifyRight", "JustifyBlock" ] },
    { "name": "styles", "items": [ "Styles", "Format"] }
]',
      'xtype' => 'textarea',
      'namespace' => 'ckeditor',
      'area' => 'general',
      'editedon' => '0000-00-00 00:00:00',
    ),
  ),
  'fea50294c03360b2d29760673648719f' => 
  array (
    'criteria' => 
    array (
      'key' => 'ckeditor.skin',
    ),
    'object' => 
    array (
      'key' => 'ckeditor.skin',
      'value' => 'moono',
      'xtype' => 'textfield',
      'namespace' => 'ckeditor',
      'area' => 'general',
      'editedon' => '0000-00-00 00:00:00',
    ),
  ),
  '4b6e43b387e245f9328580a880559a87' => 
  array (
    'criteria' => 
    array (
      'key' => 'ckeditor.extra_plugins',
    ),
    'object' => 
    array (
      'key' => 'ckeditor.extra_plugins',
      'value' => '',
      'xtype' => 'textfield',
      'namespace' => 'ckeditor',
      'area' => 'general',
      'editedon' => '0000-00-00 00:00:00',
    ),
  ),
  '5298f0e97cce8140af8e3f1bebdc799a' => 
  array (
    'criteria' => 
    array (
      'key' => 'ckeditor.object_resizing',
    ),
    'object' => 
    array (
      'key' => 'ckeditor.object_resizing',
      'value' => '0',
      'xtype' => 'combo-boolean',
      'namespace' => 'ckeditor',
      'area' => 'general',
      'editedon' => '0000-00-00 00:00:00',
    ),
  ),
);