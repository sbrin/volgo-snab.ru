<?php return array (
  '101f2df56544fc90749e0bc959c20fa3' => 
  array (
    'files' => 
    array (
      0 => '/home/u177883/stroikomplekt34.ru/www/assets/components',
    ),
  ),
);