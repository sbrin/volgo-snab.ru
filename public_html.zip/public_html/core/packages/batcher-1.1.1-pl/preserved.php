<?php return array (
  'c9565684fc6e46f9a4d1ad03dd467642' => 
  array (
    'files' => 
    array (
      0 => '/home/u177883/stroikomplekt34.ru/www/assets/components',
    ),
  ),
);