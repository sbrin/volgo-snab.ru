<?php  return array (
  'ace' => 
  array (
    'name' => 'ace',
    'path' => '/home/m/msoitggq/volgo-snab.ru/public_html/core/components/ace/',
    'assets_path' => '',
  ),
  'ajaxform' => 
  array (
    'name' => 'ajaxform',
    'path' => '/home/m/msoitggq/volgo-snab.ru/public_html/core/components/ajaxform/',
    'assets_path' => '',
  ),
  'batcher' => 
  array (
    'name' => 'batcher',
    'path' => '/home/m/msoitggq/volgo-snab.ru/public_html/core/components/batcher/',
    'assets_path' => '',
  ),
  'ckeditor' => 
  array (
    'name' => 'ckeditor',
    'path' => '/home/m/msoitggq/volgo-snab.ru/public_html/core/components/ckeditor/',
    'assets_path' => '',
  ),
  'core' => 
  array (
    'name' => 'core',
    'path' => '/home/m/msoitggq/volgo-snab.ru/public_html/manager/',
    'assets_path' => '/home/m/msoitggq/volgo-snab.ru/public_html/manager/assets/',
  ),
  'formit' => 
  array (
    'name' => 'formit',
    'path' => '/home/m/msoitggq/volgo-snab.ru/public_html/core/components/formit/',
    'assets_path' => '',
  ),
  'pdotools' => 
  array (
    'name' => 'pdotools',
    'path' => '/home/m/msoitggq/volgo-snab.ru/public_html/core/components/pdotools/',
    'assets_path' => '',
  ),
  'phpthumbof' => 
  array (
    'name' => 'phpthumbof',
    'path' => '/home/m/msoitggq/volgo-snab.ru/public_html/core/components/phpthumbof/',
    'assets_path' => '',
  ),
  'sisea' => 
  array (
    'name' => 'sisea',
    'path' => '/home/m/msoitggq/volgo-snab.ru/public_html/core/components/simplesearch/',
    'assets_path' => '/home/m/msoitggq/volgo-snab.ru/public_html/assets/components/simplesearch/',
  ),
  'translit' => 
  array (
    'name' => 'translit',
    'path' => '/home/m/msoitggq/volgo-snab.ru/public_html/core/components/translit/',
    'assets_path' => '',
  ),
  'wayfinder' => 
  array (
    'name' => 'wayfinder',
    'path' => '/home/m/msoitggq/volgo-snab.ru/public_html/core/components/wayfinder/',
    'assets_path' => '',
  ),
);