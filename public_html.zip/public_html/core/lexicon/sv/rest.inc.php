<?php
/**
 * REST lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['error'] = 'Fel!';
$_lang['rest.err_class_remove'] = 'Ett fel inträffade när [[+class_key]] skulle tas bort.';
$_lang['rest.err_class_save'] = 'Ett fel inträffade när [[+class_key]] skulle sparas.';
$_lang['rest.err_field_ns'] = '[[+field]] inte angiven!';
$_lang['rest.err_field_required'] = 'Detta fält är obligatoriskt.';
$_lang['rest.err_fields_required'] = 'Följande fält är obligatoriska: [[+fields]]';
$_lang['rest.err_obj_nf'] = '[[+class_key]] kunde inte hittas!';
