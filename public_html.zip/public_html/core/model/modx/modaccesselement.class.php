<?php
/**
 * @package modx
 */
/**
 * An ACL for restricting or allowing access to Elements
 * 
 * @property string $context_key The key of the Context this ACL refers to
 * @package modx
 */
class modAccessElement extends modAccess {}