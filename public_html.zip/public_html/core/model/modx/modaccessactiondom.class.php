<?php
/**
 * @package modx
 */
/**
 * An ACL for allowing or restricting access to Form Customization rules
 *
 * @package modx
 */
class modAccessActionDom extends modAccess {}