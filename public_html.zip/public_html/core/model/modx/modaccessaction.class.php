<?php
/**
 * @package modx
 */
/**
 * Defines an access control policy between a principal and a modAction.
 *
 * {@inheritdoc}
 *
 * @package modx
 */
class modAccessAction extends modAccess {}