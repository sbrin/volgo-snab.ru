<?php
/**
 * @package modx
 */
/**
 * @package modx
 */
class modAccessTemplateVar extends modAccessElement {}