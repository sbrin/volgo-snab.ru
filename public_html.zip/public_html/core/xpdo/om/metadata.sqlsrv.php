<?php
$xpdo_meta_map = array (
  'xPDOObject' =>
  array (
    0 => 'xPDOSimpleObject',
  ),
);